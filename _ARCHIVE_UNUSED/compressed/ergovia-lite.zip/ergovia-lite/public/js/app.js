// ============================================
// ERGOVIA LITE - Frontend JavaScript
// ============================================

const API = {
  // Client data
  async getClient() {
    const res = await fetch('/api/client');
    return res.json();
  },

  async saveClientSection(section, data) {
    const res = await fetch(`/api/client/${section}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async saveAllClient(data) {
    const res = await fetch('/api/client', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async resetClient() {
    const res = await fetch('/api/client/reset', { method: 'POST' });
    return res.json();
  },

  // Services
  async getServices() {
    const res = await fetch('/api/services');
    return res.json();
  },

  async getServicesStatus() {
    const res = await fetch('/api/services/status');
    return res.json();
  },

  async enableService(id) {
    const res = await fetch(`/api/services/${id}/enable`, { method: 'POST' });
    return res.json();
  },

  async disableService(id) {
    const res = await fetch(`/api/services/${id}/disable`, { method: 'POST' });
    return res.json();
  },

  // Activity
  async getActivity(limit = 10) {
    const res = await fetch(`/api/activity?limit=${limit}`);
    return res.json();
  },

  // Status
  async getStatus() {
    const res = await fetch('/api/status');
    return res.json();
  }
};

// ============================================
// UTILITY FUNCTIONS
// ============================================

function showAlert(message, type = 'info') {
  const alertDiv = document.createElement('div');
  alertDiv.className = `alert alert-${type}`;
  alertDiv.textContent = message;

  const container = document.querySelector('.container');
  if (container) {
    container.insertBefore(alertDiv, container.firstChild);
    setTimeout(() => alertDiv.remove(), 5000);
  }
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function getFormData(formId) {
  const form = document.getElementById(formId);
  if (!form) return {};

  const formData = new FormData(form);
  const data = {};

  for (const [key, value] of formData.entries()) {
    // Handle array fields (like cleaners)
    if (key.endsWith('[]')) {
      const arrayKey = key.slice(0, -2);
      if (!data[arrayKey]) data[arrayKey] = [];
      data[arrayKey].push(value);
    } else {
      data[key] = value;
    }
  }

  return data;
}

function populateForm(formId, data) {
  const form = document.getElementById(formId);
  if (!form || !data) return;

  for (const [key, value] of Object.entries(data)) {
    const input = form.querySelector(`[name="${key}"]`);
    if (input) {
      if (input.type === 'checkbox') {
        input.checked = !!value;
      } else {
        input.value = value || '';
      }
    }
  }
}

// ============================================
// ONBOARDING WIZARD
// ============================================

class OnboardingWizard {
  constructor() {
    this.currentStep = 1;
    this.totalSteps = 5;
    this.data = {};
  }

  async init() {
    // Load existing data
    const result = await API.getClient();
    if (result.success && result.data) {
      this.data = result.data;
    }

    // Check which step to start from
    if (this.data.owner) this.currentStep = 2;
    if (this.data.property) this.currentStep = 3;
    if (this.data.guestAccess) this.currentStep = 4;
    if (this.data.calendars) this.currentStep = 5;

    this.render();
    this.bindEvents();
  }

  render() {
    this.updateStepIndicators();
    this.showCurrentStep();
    this.populateCurrentStep();
  }

  updateStepIndicators() {
    document.querySelectorAll('.step').forEach((step, index) => {
      const stepNum = index + 1;
      step.classList.remove('active', 'completed');

      if (stepNum < this.currentStep) {
        step.classList.add('completed');
      } else if (stepNum === this.currentStep) {
        step.classList.add('active');
      }
    });
  }

  showCurrentStep() {
    document.querySelectorAll('.step-content').forEach((content, index) => {
      content.classList.remove('active');
      if (index + 1 === this.currentStep) {
        content.classList.add('active');
      }
    });
  }

  populateCurrentStep() {
    const stepData = this.getStepData();
    if (stepData) {
      populateForm(`step${this.currentStep}-form`, stepData);
    }
  }

  getStepData() {
    const sections = ['owner', 'property', 'guestAccess', 'calendars', 'integrations'];
    return this.data[sections[this.currentStep - 1]];
  }

  bindEvents() {
    // Next buttons
    document.querySelectorAll('.btn-next').forEach(btn => {
      btn.addEventListener('click', () => this.nextStep());
    });

    // Previous buttons
    document.querySelectorAll('.btn-prev').forEach(btn => {
      btn.addEventListener('click', () => this.prevStep());
    });

    // Complete button
    const completeBtn = document.querySelector('.btn-complete');
    if (completeBtn) {
      completeBtn.addEventListener('click', () => this.complete());
    }

    // Platform selection (show/hide conditional fields)
    const platformSelect = document.querySelector('[name="preferredPlatform"]');
    if (platformSelect) {
      platformSelect.addEventListener('change', (e) => {
        this.togglePlatformFields(e.target.value);
      });
    }
  }

  togglePlatformFields(platform) {
    const telegramField = document.getElementById('telegram-field');
    const whatsappField = document.getElementById('whatsapp-field');

    if (telegramField) {
      telegramField.classList.toggle('hidden', platform !== 'telegram');
    }
    if (whatsappField) {
      whatsappField.classList.toggle('hidden', platform !== 'whatsapp');
    }
  }

  async saveCurrentStep() {
    const sections = ['owner', 'property', 'guestAccess', 'calendars', 'integrations'];
    const section = sections[this.currentStep - 1];
    const formData = getFormData(`step${this.currentStep}-form`);

    this.data[section] = formData;

    const result = await API.saveClientSection(section, formData);
    return result.success;
  }

  async nextStep() {
    if (await this.saveCurrentStep()) {
      if (this.currentStep < this.totalSteps) {
        this.currentStep++;
        this.render();
      }
    } else {
      showAlert('Failed to save. Please try again.', 'danger');
    }
  }

  prevStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
      this.render();
    }
  }

  async complete() {
    if (await this.saveCurrentStep()) {
      showAlert('Onboarding complete!', 'success');
      setTimeout(() => {
        window.location.href = '/dashboard.html';
      }, 1500);
    } else {
      showAlert('Failed to save. Please try again.', 'danger');
    }
  }
}

// ============================================
// DASHBOARD
// ============================================

class Dashboard {
  async init() {
    await this.loadStatus();
    await this.loadActivity();
    this.bindEvents();
  }

  async loadStatus() {
    const result = await API.getStatus();
    if (result.success) {
      const status = result.status;

      // Update stats
      const enabledEl = document.getElementById('enabled-services');
      const totalEl = document.getElementById('total-services');
      const statusEl = document.getElementById('automation-status');

      if (enabledEl) enabledEl.textContent = status.enabledServices;
      if (totalEl) totalEl.textContent = status.totalServices;

      if (statusEl) {
        const statusMap = {
          'connected': { text: 'Connected', class: 'badge-success' },
          'configured': { text: 'Ready', class: 'badge-success' },
          'not_configured': { text: 'Not Configured', class: 'badge-warning' },
          'error': { text: 'Error', class: 'badge-danger' }
        };
        const s = statusMap[status.automationStatus] || statusMap['not_configured'];
        statusEl.textContent = s.text;
        statusEl.className = 'badge ' + s.class;
      }
    }
  }

  async loadActivity() {
    const result = await API.getActivity(5);
    const list = document.getElementById('activity-list');
    if (!list || !result.success) return;

    if (result.activity.length === 0) {
      list.innerHTML = '<li class="activity-item"><p class="text-muted">No recent activity</p></li>';
      return;
    }

    list.innerHTML = result.activity.map(item => `
      <li class="activity-item">
        <div class="activity-icon">
          <span>${this.getActivityIcon(item.action)}</span>
        </div>
        <div class="activity-content">
          <p class="activity-text">${item.action.replace(/_/g, ' ')}</p>
          <p class="activity-time">${formatDate(item.created_at)}</p>
        </div>
      </li>
    `).join('');
  }

  getActivityIcon(action) {
    const icons = {
      'service_enabled': '✓',
      'service_disabled': '✕',
      'data_saved': '💾',
      'onboarding_completed': '🎉',
      'data_reset': '🔄'
    };
    return icons[action] || '•';
  }

  bindEvents() {
    const resetBtn = document.getElementById('reset-btn');
    if (resetBtn) {
      resetBtn.addEventListener('click', async () => {
        if (confirm('Are you sure you want to reset all data? This cannot be undone.')) {
          await API.resetClient();
          showAlert('Data reset successfully', 'success');
          setTimeout(() => location.reload(), 1000);
        }
      });
    }
  }
}

// ============================================
// AUTOMATIONS PAGE
// ============================================

class Automations {
  async init() {
    await this.loadServices();
    this.bindEvents();
  }

  async loadServices() {
    const result = await API.getServices();
    const list = document.getElementById('services-list');
    if (!list || !result.success) return;

    list.innerHTML = result.services.map(service => `
      <div class="service-item" data-id="${service.service_id}">
        <div class="service-info">
          <h4 class="service-name">${service.display_name}</h4>
          <p class="service-desc">${service.description || ''}</p>
        </div>
        <div class="service-status">
          <span class="badge ${service.is_enabled ? 'badge-success' : 'badge-gray'}">
            ${service.is_enabled ? 'Active' : 'Inactive'}
          </span>
          <label class="toggle-switch">
            <input type="checkbox" ${service.is_enabled ? 'checked' : ''}>
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>
    `).join('');
  }

  bindEvents() {
    document.addEventListener('change', async (e) => {
      if (e.target.closest('.toggle-switch input')) {
        const serviceItem = e.target.closest('.service-item');
        const serviceId = serviceItem?.dataset.id;
        const isEnabled = e.target.checked;

        if (!serviceId) return;

        // Show loading state
        const badge = serviceItem.querySelector('.badge');
        const originalText = badge.textContent;
        badge.textContent = 'Loading...';
        badge.className = 'badge badge-gray';
        e.target.disabled = true;

        try {
          const result = isEnabled
            ? await API.enableService(serviceId)
            : await API.disableService(serviceId);

          if (result.success) {
            badge.textContent = isEnabled ? 'Active' : 'Inactive';
            badge.className = `badge ${isEnabled ? 'badge-success' : 'badge-gray'}`;
            showAlert(result.message || `Service ${isEnabled ? 'enabled' : 'disabled'}`, 'success');
          } else {
            // Revert toggle
            e.target.checked = !isEnabled;
            badge.textContent = originalText;
            badge.className = `badge ${!isEnabled ? 'badge-success' : 'badge-gray'}`;
            showAlert(result.error || 'Failed to update service', 'danger');
          }
        } catch (err) {
          e.target.checked = !isEnabled;
          badge.textContent = originalText;
          badge.className = `badge ${!isEnabled ? 'badge-success' : 'badge-gray'}`;
          showAlert('Network error. Please try again.', 'danger');
        }

        e.target.disabled = false;
      }
    });
  }
}

// ============================================
// SETTINGS PAGE
// ============================================

class Settings {
  async init() {
    await this.loadData();
    this.bindEvents();
  }

  async loadData() {
    const result = await API.getClient();
    if (result.success && result.data) {
      // Populate each section form
      populateForm('owner-form', result.data.owner);
      populateForm('property-form', result.data.property);
      populateForm('guestAccess-form', result.data.guestAccess);
      populateForm('calendars-form', result.data.calendars);
      populateForm('integrations-form', result.data.integrations);
    }
  }

  bindEvents() {
    // Save buttons for each section
    document.querySelectorAll('.save-section-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const section = e.target.dataset.section;
        const formData = getFormData(`${section}-form`);

        btn.disabled = true;
        btn.textContent = 'Saving...';

        const result = await API.saveClientSection(section, formData);

        btn.disabled = false;
        btn.textContent = 'Save';

        if (result.success) {
          showAlert(`${section} settings saved`, 'success');
        } else {
          showAlert('Failed to save settings', 'danger');
        }
      });
    });
  }
}

// ============================================
// PAGE INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  const page = document.body.dataset.page;

  switch (page) {
    case 'onboarding':
      new OnboardingWizard().init();
      break;
    case 'dashboard':
      new Dashboard().init();
      break;
    case 'automations':
      new Automations().init();
      break;
    case 'settings':
      new Settings().init();
      break;
  }
});
