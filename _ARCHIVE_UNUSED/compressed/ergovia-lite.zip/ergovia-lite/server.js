require('dotenv').config();
const express = require('express');
const path = require('path');
const db = require('./db');
const n8nService = require('./services/n8n');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Initialize database
db.initDb();

// ============================================
// ROUTES
// ============================================

// Redirect root to dashboard
app.get('/', (req, res) => {
  if (db.isOnboardingComplete()) {
    res.redirect('/dashboard.html');
  } else {
    res.redirect('/onboarding.html');
  }
});

// ============================================
// CLIENT DATA API
// ============================================

// Get all client data
app.get('/api/client', (req, res) => {
  try {
    const data = db.getAllClientData();
    const isComplete = db.isOnboardingComplete();
    res.json({ success: true, data, onboardingComplete: isComplete });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get specific section
app.get('/api/client/:section', (req, res) => {
  try {
    const data = db.getClientData(req.params.section);
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Save client data (single section)
app.post('/api/client/:section', (req, res) => {
  try {
    db.saveClientData(req.params.section, req.body);
    db.logActivity('data_saved', `Section: ${req.params.section}`);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Save all client data
app.post('/api/client', (req, res) => {
  try {
    for (const [section, data] of Object.entries(req.body)) {
      db.saveClientData(section, data);
    }
    db.logActivity('onboarding_completed', 'All sections saved');
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Reset all data
app.post('/api/client/reset', (req, res) => {
  try {
    db.resetClientData();
    db.logActivity('data_reset', 'All client data cleared');
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// SERVICES API (Automations)
// ============================================

// Get all services
app.get('/api/services', (req, res) => {
  try {
    const services = db.getAllServices();
    res.json({ success: true, services });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get services status summary
app.get('/api/services/status', (req, res) => {
  try {
    const services = db.getAllServices();
    const enabled = services.filter(s => s.is_enabled).length;
    const total = services.length;
    res.json({
      success: true,
      enabled,
      total,
      services: services.map(s => ({
        id: s.service_id,
        name: s.display_name,
        enabled: !!s.is_enabled
      }))
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Enable a service
app.post('/api/services/:id/enable', async (req, res) => {
  try {
    const serviceId = req.params.id;
    const service = db.getService(serviceId);

    if (!service) {
      return res.status(404).json({ success: false, error: 'Service not found' });
    }

    if (service.is_enabled) {
      return res.json({ success: true, message: 'Service already enabled' });
    }

    // Check if n8n is configured
    if (!n8nService.isConfigured()) {
      return res.status(400).json({
        success: false,
        error: 'Automation system not configured. Please contact support.'
      });
    }

    // Get client data for personalization
    const clientData = db.getAllClientData();

    if (!clientData.owner || !clientData.property) {
      return res.status(400).json({
        success: false,
        error: 'Please complete onboarding before enabling services'
      });
    }

    // Deploy the workflow(s) for this service
    const result = await n8nService.deployService(serviceId, clientData);

    if (result.success) {
      db.enableService(serviceId, result.workflowId);
      db.logActivity('service_enabled', `Service: ${service.display_name}`);
      res.json({ success: true, message: `${service.display_name} activated` });
    } else {
      res.status(500).json({ success: false, error: result.error });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Disable a service
app.post('/api/services/:id/disable', async (req, res) => {
  try {
    const serviceId = req.params.id;
    const service = db.getService(serviceId);

    if (!service) {
      return res.status(404).json({ success: false, error: 'Service not found' });
    }

    if (!service.is_enabled) {
      return res.json({ success: true, message: 'Service already disabled' });
    }

    // Deactivate in n8n if we have a workflow ID
    if (service.n8n_workflow_id && n8nService.isConfigured()) {
      await n8nService.deactivateWorkflow(service.n8n_workflow_id);
    }

    db.disableService(serviceId);
    db.logActivity('service_disabled', `Service: ${service.display_name}`);
    res.json({ success: true, message: `${service.display_name} deactivated` });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// ACTIVITY LOG API
// ============================================

app.get('/api/activity', (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const activity = db.getRecentActivity(limit);
    res.json({ success: true, activity });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// SYSTEM STATUS API
// ============================================

app.get('/api/status', async (req, res) => {
  try {
    const onboardingComplete = db.isOnboardingComplete();
    const services = db.getAllServices();
    const enabledServices = services.filter(s => s.is_enabled).length;

    // Test n8n connection (don't expose details to client)
    let automationStatus = 'configured';
    if (!n8nService.isConfigured()) {
      automationStatus = 'not_configured';
    } else {
      const test = await n8nService.testConnection();
      automationStatus = test.success ? 'connected' : 'error';
    }

    res.json({
      success: true,
      status: {
        onboardingComplete,
        enabledServices,
        totalServices: services.length,
        automationStatus // 'configured', 'not_configured', 'connected', 'error'
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// START SERVER
// ============================================

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Ergovia Lite running on port ${PORT}`);
  console.log(`n8n configured: ${n8nService.isConfigured()}`);
});
