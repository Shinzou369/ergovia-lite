const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, 'data.db');
const db = new Database(dbPath);

// Initialize database tables
function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS client_data (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      section TEXT NOT NULL UNIQUE,
      data TEXT NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS enabled_services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      service_id TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      description TEXT,
      n8n_workflow_id TEXT,
      is_enabled INTEGER DEFAULT 0,
      enabled_at DATETIME
    );

    CREATE TABLE IF NOT EXISTS activity_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      action TEXT NOT NULL,
      details TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Seed default services
  const services = [
    { id: 'guest_messaging', name: 'Guest Messaging', desc: 'Automatically send check-in info, welcome messages, and departure reminders' },
    { id: 'cleaning_alerts', name: 'Cleaning Alerts', desc: 'Alert cleaners when guests check out and track cleaning completion' },
    { id: 'booking_notifications', name: 'Booking Notifications', desc: 'Get notified of new bookings, inquiries, and booking changes' },
    { id: 'calendar_sync', name: 'Calendar Sync', desc: 'Keep all booking calendars synchronized and detect conflicts' },
    { id: 'review_requests', name: 'Review Requests', desc: 'Automatically request guest reviews after checkout' },
    { id: 'smart_inquiries', name: 'Smart Inquiries', desc: 'AI-powered inquiry handling and guest conversation' },
    { id: 'daily_reports', name: 'Daily Reports', desc: 'Receive daily summary of bookings, tasks, and property status' }
  ];

  const insertService = db.prepare(`
    INSERT OR IGNORE INTO enabled_services (service_id, display_name, description, is_enabled)
    VALUES (?, ?, ?, 0)
  `);

  for (const svc of services) {
    insertService.run(svc.id, svc.name, svc.desc);
  }

  console.log('Database initialized successfully');
}

// Client data operations
function getClientData(section) {
  const row = db.prepare('SELECT data FROM client_data WHERE section = ?').get(section);
  return row ? JSON.parse(row.data) : null;
}

function getAllClientData() {
  const rows = db.prepare('SELECT section, data FROM client_data').all();
  const result = {};
  for (const row of rows) {
    result[row.section] = JSON.parse(row.data);
  }
  return result;
}

function saveClientData(section, data) {
  db.prepare(`
    INSERT INTO client_data (section, data, updated_at)
    VALUES (?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(section) DO UPDATE SET data = ?, updated_at = CURRENT_TIMESTAMP
  `).run(section, JSON.stringify(data), JSON.stringify(data));
}

function resetClientData() {
  db.exec('DELETE FROM client_data');
  db.exec('UPDATE enabled_services SET is_enabled = 0, n8n_workflow_id = NULL, enabled_at = NULL');
  db.exec('DELETE FROM activity_log');
}

// Service operations
function getAllServices() {
  return db.prepare('SELECT * FROM enabled_services ORDER BY id').all();
}

function getService(serviceId) {
  return db.prepare('SELECT * FROM enabled_services WHERE service_id = ?').get(serviceId);
}

function enableService(serviceId, n8nWorkflowId) {
  db.prepare(`
    UPDATE enabled_services
    SET is_enabled = 1, n8n_workflow_id = ?, enabled_at = CURRENT_TIMESTAMP
    WHERE service_id = ?
  `).run(n8nWorkflowId, serviceId);
}

function disableService(serviceId) {
  db.prepare(`
    UPDATE enabled_services
    SET is_enabled = 0, enabled_at = NULL
    WHERE service_id = ?
  `).run(serviceId);
}

// Activity log
function logActivity(action, details) {
  db.prepare('INSERT INTO activity_log (action, details) VALUES (?, ?)').run(action, details);
}

function getRecentActivity(limit = 10) {
  return db.prepare('SELECT * FROM activity_log ORDER BY created_at DESC LIMIT ?').all(limit);
}

// Check if onboarding is complete
function isOnboardingComplete() {
  const required = ['owner', 'property', 'guestAccess'];
  for (const section of required) {
    if (!getClientData(section)) return false;
  }
  return true;
}

module.exports = {
  initDb,
  getClientData,
  getAllClientData,
  saveClientData,
  resetClientData,
  getAllServices,
  getService,
  enableService,
  disableService,
  logActivity,
  getRecentActivity,
  isOnboardingComplete
};
