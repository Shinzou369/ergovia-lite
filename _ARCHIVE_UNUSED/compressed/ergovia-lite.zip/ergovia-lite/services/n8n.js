const axios = require('axios');
const fs = require('fs');
const path = require('path');

class N8NService {
  constructor() {
    this.baseUrl = process.env.N8N_URL;
    this.apiKey = process.env.N8N_API_KEY;
    this.postgresCredentialId = process.env.N8N_POSTGRES_CREDENTIAL_ID;

    // Service to workflow mapping
    this.serviceWorkflowMap = {
      'guest_messaging': ['Workflow_08_PostgreSQL_PERFECT.json'],
      'cleaning_alerts': ['Workflow_10_PostgreSQL_PERFECT.json'],
      'booking_notifications': ['Workflow_09_PostgreSQL_PERFECT.json'],
      'calendar_sync': ['Workflow_03_PostgreSQL_PERFECT.json'],
      'review_requests': ['Workflow_16_PostgreSQL_PERFECT.json'],
      'smart_inquiries': ['Workflow_05_PostgreSQL_PERFECT.json', 'Workflow_06_PostgreSQL_PERFECT.json'],
      'daily_reports': ['Workflow_23_PostgreSQL_PERFECT.json']
    };

    // Core workflows that are always deployed
    this.coreWorkflows = [
      'Workflow_00_PostgreSQL_PERFECT.json',
      'Workflow_01_PostgreSQL_PERFECT.json'
    ];
  }

  isConfigured() {
    return !!(this.baseUrl && this.apiKey);
  }

  async testConnection() {
    if (!this.isConfigured()) {
      return { success: false, error: 'n8n not configured' };
    }

    try {
      const response = await axios.get(`${this.baseUrl}/api/v1/workflows`, {
        headers: { 'X-N8N-API-KEY': this.apiKey },
        timeout: 10000
      });
      return { success: true, workflowCount: response.data.data?.length || 0 };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Load workflow template from file
  loadWorkflowTemplate(filename) {
    const workflowPath = path.join(__dirname, '..', 'workflows', filename);
    if (!fs.existsSync(workflowPath)) {
      throw new Error(`Workflow template not found: ${filename}`);
    }
    const content = fs.readFileSync(workflowPath, 'utf8');
    return JSON.parse(content);
  }

  // Replace placeholders in workflow with client data
  personalizeWorkflow(workflow, clientData) {
    let workflowStr = JSON.stringify(workflow);

    const owner = clientData.owner || {};
    const property = clientData.property || {};
    const guestAccess = clientData.guestAccess || {};
    const integrations = clientData.integrations || {};
    const calendars = clientData.calendars || {};

    // Build placeholder replacements
    const replacements = {
      // Owner info
      '<__PLACEHOLDER_VALUE__Property Owner Name__>': owner.ownerName || '',
      '<__PLACEHOLDER_VALUE__Property Owner ID__>': owner.telegramChatId || owner.ownerPhone || '',
      '<__PLACEHOLDER_VALUE__Owner Telegram/Phone ID__>': owner.telegramChatId || owner.ownerPhone || '',
      '<__PLACEHOLDER_VALUE__From Email Address__>': owner.ownerEmail || '',

      // Manager info
      '<__PLACEHOLDER_VALUE__Manager Name__>': integrations.managerName || owner.ownerName || '',
      '<__PLACEHOLDER_VALUE__Manager Platform (sms/whatsapp/telegram)__>': integrations.managerPlatform || owner.preferredPlatform || 'telegram',
      '<__PLACEHOLDER_VALUE__Manager Contact (phone/chat ID)__>': integrations.managerContact || owner.telegramChatId || owner.ownerPhone || '',

      // Communication channels
      '<__PLACEHOLDER_VALUE__Twilio_From_Phone_Number__>': integrations.twilioPhoneNumber || '',
      '<__PLACEHOLDER_VALUE__Twilio_WhatsApp_From_Number__>': integrations.twilioWhatsAppNumber || '',
      '<__PLACEHOLDER_VALUE__Twilio Phone Number__>': integrations.twilioPhoneNumber || '',
      '<__PLACEHOLDER_VALUE__Twilio From Phone Number__>': integrations.twilioPhoneNumber || '',
      '<__PLACEHOLDER_VALUE__Twilio SMS Number__>': integrations.twilioPhoneNumber || '',
      '<__PLACEHOLDER_VALUE__WhatsApp Phone Number ID__>': integrations.whatsappPhoneNumberId || '',

      // Platform preferences
      '<__PLACEHOLDER_VALUE__telegram or whatsapp__>': owner.preferredPlatform || 'telegram',
      '<__PLACEHOLDER_VALUE__Booking contact platform (telegram or whatsapp)__>': owner.preferredPlatform || 'telegram',
      '<__PLACEHOLDER_VALUE__Booking contact chat ID or phone number__>': owner.telegramChatId || owner.ownerPhone || '',
      '<__PLACEHOLDER_VALUE__Booking Contact Phone Number__>': owner.ownerPhone || '',
      '<__PLACEHOLDER_VALUE__Booking Contact Platform (telegram or whatsapp)__>': owner.preferredPlatform || 'telegram',
      '<__PLACEHOLDER_VALUE__Booking Contact Chat ID (for Telegram)__>': owner.telegramChatId || '',

      // API Keys
      '<__PLACEHOLDER_VALUE__OpenAI API Key__>': integrations.openaiApiKey || '',
      '<__PLACEHOLDER_VALUE__Eventbrite API Token__>': integrations.eventbriteApiToken || '',
      '<__PLACEHOLDER_VALUE__OpenWeatherMap API Key__>': integrations.openWeatherMapApiKey || '',

      // Credential IDs
      '{{ POSTGRES_CREDENTIAL_ID }}': this.postgresCredentialId || '',

      // URLs - will be updated after deployment with actual webhook URLs
      '<__PLACEHOLDER_VALUE__Availability_Checker_Webhook_URL__>': '',
      '<__PLACEHOLDER_VALUE__Guest Journey Scheduler Webhook URL__>': '',
      '<__PLACEHOLDER_VALUE__Calendar Sync Reminder Webhook URL__>': '',
      '<__PLACEHOLDER_VALUE__Cleaning Scheduler Webhook URL__>': '',
      '<__PLACEHOLDER_VALUE__Inventory Predictor Webhook URL__>': '',
      '<__PLACEHOLDER_VALUE__Task Completed Webhook URL__>': '',
      '<__PLACEHOLDER_VALUE__Property Status Update Webhook URL__>': '',
      '<__PLACEHOLDER_VALUE__Send Guest Message Webhook URL__>': '',
      '<__PLACEHOLDER_VALUE__Maintenance Ticket Creator Webhook URL__>': '',
      '<__PLACEHOLDER_VALUE__Property details URL__>': '',
      '<__PLACEHOLDER_VALUE__URL to task dashboard for contacts__>': ''
    };

    // Apply all replacements
    for (const [placeholder, value] of Object.entries(replacements)) {
      workflowStr = workflowStr.split(placeholder).join(value);
    }

    // Also replace any hardcoded n8n URLs with user's n8n URL
    workflowStr = workflowStr.replace(/https:\/\/bybless\.app\.n8n\.cloud/g, this.baseUrl || '');

    return JSON.parse(workflowStr);
  }

  // Deploy a workflow to n8n
  async deployWorkflow(workflow, clientName) {
    if (!this.isConfigured()) {
      throw new Error('n8n not configured');
    }

    // Prefix workflow name with client name
    const prefixedName = `[${clientName}] ${workflow.name}`;
    workflow.name = prefixedName;

    // Remove IDs that would conflict
    delete workflow.id;
    delete workflow.versionId;

    // Remove webhookIds from nodes
    if (workflow.nodes) {
      for (const node of workflow.nodes) {
        delete node.webhookId;
      }
    }

    try {
      const response = await axios.post(
        `${this.baseUrl}/api/v1/workflows`,
        workflow,
        {
          headers: {
            'X-N8N-API-KEY': this.apiKey,
            'Content-Type': 'application/json'
          },
          timeout: 30000
        }
      );
      return { success: true, workflowId: response.data.id, name: prefixedName };
    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.message || error.message
      };
    }
  }

  // Activate a workflow in n8n
  async activateWorkflow(workflowId) {
    try {
      await axios.patch(
        `${this.baseUrl}/api/v1/workflows/${workflowId}`,
        { active: true },
        {
          headers: {
            'X-N8N-API-KEY': this.apiKey,
            'Content-Type': 'application/json'
          }
        }
      );
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Deactivate a workflow in n8n
  async deactivateWorkflow(workflowId) {
    try {
      await axios.patch(
        `${this.baseUrl}/api/v1/workflows/${workflowId}`,
        { active: false },
        {
          headers: {
            'X-N8N-API-KEY': this.apiKey,
            'Content-Type': 'application/json'
          }
        }
      );
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Delete a workflow from n8n
  async deleteWorkflow(workflowId) {
    try {
      await axios.delete(
        `${this.baseUrl}/api/v1/workflows/${workflowId}`,
        {
          headers: { 'X-N8N-API-KEY': this.apiKey }
        }
      );
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Deploy a service (one or more workflows)
  async deployService(serviceId, clientData) {
    const workflowFiles = this.serviceWorkflowMap[serviceId];
    if (!workflowFiles) {
      throw new Error(`Unknown service: ${serviceId}`);
    }

    const clientName = clientData.property?.propertyName || clientData.owner?.ownerName || 'Client';
    const results = [];

    for (const filename of workflowFiles) {
      try {
        const template = this.loadWorkflowTemplate(filename);
        const personalized = this.personalizeWorkflow(template, clientData);
        const result = await this.deployWorkflow(personalized, clientName);

        if (result.success) {
          // Activate the workflow
          await this.activateWorkflow(result.workflowId);
        }

        results.push({ filename, ...result });
      } catch (error) {
        results.push({ filename, success: false, error: error.message });
      }
    }

    // Return the first workflow ID (for simple services) or all results
    const successResults = results.filter(r => r.success);
    if (successResults.length > 0) {
      return {
        success: true,
        workflowId: successResults[0].workflowId,
        allResults: results
      };
    }

    return { success: false, error: results[0]?.error || 'Deployment failed', allResults: results };
  }
}

module.exports = new N8NService();
